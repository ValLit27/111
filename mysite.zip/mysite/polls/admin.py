from django.contrib import admin
from .models import *


class StudentAdmin(admin.ModelAdmin):
    list_display = ['name', 'group', 'age', 'adress']
    search_fields = ['name', 'group__group']

class LessonAdmin(admin.ModelAdmin):
    list_display = ['date', 'group', 'discipline']

class DisciplineAdmin(admin.ModelAdmin):
    list_display = ['discipline', 'lector']

class MarksAdmin(admin.ModelAdmin):
    list_display = ['mark', 'student', 'lesson']

admin.site.register(Student, StudentAdmin)
admin.site.register(Group)
admin.site.register(Lesson, LessonAdmin)
admin.site.register(Discipline, DisciplineAdmin)
admin.site.register(Marks, MarksAdmin)
