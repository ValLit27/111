from django import forms
from .models import *

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['name','group']

class LessonForm(forms.ModelForm):
    class Meta:
        model = Lesson
        fields = ['date', 'group', 'discipline']

class MarksForm(forms.ModelForm):
    def __init__(self, lesson_id, *args, **kwargs):
        super(MarksForm, self).__init__(*args, **kwargs)
        lesson = Lesson.objects.get(id = lesson_id)
        self.fields['student']= forms.ModelChoiceField(queryset=Student.objects.filter(group = lesson.group))
        self.initial['lesson'] = lesson

    class Meta:
        model = Marks
        fields = ['mark', 'student']