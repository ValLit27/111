from django.shortcuts import render, redirect
from .models import *
from .forms import *
from django.http import HttpResponse


def index(request):
    student = Student.objects.all()
    group = Group.objects.all()
    context = {'students': student, 'groups': group}
    return render(request, 'base.html', context)

def adding(request):
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/")

    else:
        form = StudentForm()
    return render(request, "name.html", {"form": form})

def list_students(request):
    students = Student.objects.all()
    return render(request, 'list_students.html', {'students': students})

def list_groups(request):
    groups = Group.objects.all()
    return render(request, 'list_group.html', {'groups': groups})

def list_disciplines(request):
    disciplines = Discipline.objects.all()
    return render(request, 'list_disciplines.html', {'disciplines': disciplines})

def list_marks(request):
    marks = Marks.objects.all()
    return render(request, 'list_marks.html', {'marks': marks})

def student_by_group(request, group_name):
    students = Student.objects.filter(group__group=group_name)
    return render(request, 'student_by_group.html', {'students': students, 'group': group_name})

def add_lesson(request):
    if request.method == "POST":
        form = LessonForm(request.POST)
        if form.is_valid():
            obj = Lesson(date=form.cleaned_data['date'], group=form.cleaned_data['group'], discipline= form.cleaned_data['discipline'])
            obj.save()
            return redirect(f"/add_marks/{obj.id}")

    else:
        form = LessonForm()


    return render(request, "lessons.html", {"form": form})

def add_marks(request, lesson_id):
    if request.method == "POST":
        form = MarksForm(lesson_id, request.POST)
        if form.is_valid():
            Marks.objects.create(mark=form.cleaned_data['mark'], student=form.cleaned_data['student'], lesson=Lesson.objects.get(id=lesson_id))
    else:

        form = MarksForm(lesson_id)

    return render(request, "marks.html", {"form": form})

def see_marks(request, student_id):
    student_obj = Student.objects.get(id=student_id)
    lessons = Lesson.objects.filter(group=student_obj.group)
    marks = Marks.objects.filter(student=student_obj.id)

    final = {}

    for lesson in lessons:
        les = lesson.discipline.discipline
        if les not in final.keys():
            final[les] = {}
        for mark in marks:
            if mark.lesson.date not in final[mark.lesson.discipline.discipline].keys():
                final[mark.lesson.discipline.discipline][mark.lesson.date] = [mark.mark]
            else:
                final[mark.lesson.discipline.discipline][mark.lesson.date].append(mark.mark)


    return (request, 'see_marks.html', {'final': final, 'student': student_obj})