from django.db import models
from django.contrib.auth.models import User


class Student(models.Model):
    name = models.OneToOneField(User, on_delete=models.CASCADE)
    group = models.ForeignKey("Group", on_delete=models.CASCADE)
    age = models.IntegerField()
    adress = models.CharField(max_length=70)

    def __str__(self):
        return f'{self.name}, {self.group.group}'

    class Meta:
        ordering = ['name']
        verbose_name = 'Студент'
        verbose_name_plural = 'Студенты'


class Group(models.Model):
    group = models.CharField(max_length=50)

    def __str__(self):
        return self.group

    class Meta:
        ordering = ['group']
        verbose_name = 'Группа'
        verbose_name_plural = 'Группы'


class Lesson(models.Model):
    date = models.DateField()
    group = models.ForeignKey("Group", on_delete=models.CASCADE)
    discipline = models.ForeignKey("Discipline", on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.date}, {self.group.group}, {self.discipline.discipline}'

    class Meta:
        ordering = ['date']
        verbose_name = 'Пара'
        verbose_name_plural = 'Пары'


class Discipline(models.Model):
    discipline = models.CharField(max_length=70)
    lector = models.OneToOneField(User, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.discipline}, {self.lector}'

    class Meta:
        ordering = ['discipline']
        verbose_name = 'Дисциплина'
        verbose_name_plural = 'Дисциплина'


class Marks(models.Model):
    marks = (('n', 'n'), ('2', '2'), ('3', '3'), ('4', '4'), ('5', '5'))
    mark = models.CharField(max_length=1, choices=marks, null=True, blank=True)
    student = models.ForeignKey("Student", on_delete=models.CASCADE)
    lesson = models.ForeignKey("Lesson", on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.mark}, {self.student.name.last_name}, {self.lesson.discipline}'

    class Meta:
        ordering = ['mark']
        verbose_name = 'Оценка'
        verbose_name_plural = 'Оценки'
