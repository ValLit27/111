from django.urls import path
from polls.views import *

urlpatterns = [
    path('', index),
    path('add/', adding),
    path('students/', list_students, name = 'students'),
    path('groups/', list_groups, name='groups'),
    path('disciplines/', list_disciplines, name='disciplines'),
    path('add_lesson/', add_lesson, name='add_lesson'),
    path('marks/', list_marks, name='marks'),
    path('groups/<group_name>/', student_by_group, name='student_by_group'),
    path('see_marks/<int:student_id>', see_marks, name='see_marks'),
    path('add_marks/<int:lesson_id>/', add_marks, name='add_marks')

]